import UIKit

enum meat: CaseIterable {
    case Chicken
}
enum veggies: CaseIterable {
    case greenPeppers , lettuce , spinich
}
enum bread: CaseIterable {
    case WhiteBread
}
enum MySandwhich: CaseIterable {
    case MyUltimateSandwhich
}
print(MySandwhich.MyUltimateSandwhich)
print(meat.Chicken)
print(veggies.greenPeppers)
print(veggies.lettuce)
print(veggies.spinich)
print(bread.WhiteBread)
